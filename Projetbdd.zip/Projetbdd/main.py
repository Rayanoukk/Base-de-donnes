import random
import datetime
from flask import Flask, render_template, request, redirect, url_for, session
from passlib.context import CryptContext
import db
app = Flask(__name__)
app.secret_key = 'clefsecrete'
lstype=['Entreprise','Association','Institution','Contact']

@app.route("/acceuil")
def acceuil():
    return render_template("/acceuil.html")

@app.route("/créent")
def créent():
     return render_template("/créent.html" , erreur = '' )


@app.route("/demandentreprise", methods = ['POST'])
def demendentreprise():
    nomm = request.form.get("nom",None)
    siglee = request.form.get("sigle",None)
    adressee = request.form.get("adresse",None)
    tele = request.form.get("tel",None)
    maile = request.form.get("mail",None)
    if nomm == '' or siglee == '' or  adressee == '' or  tele == '' or maile == '' :
        resultat= 0
        return render_template("créeass.html",erreur= resultat )
    else:
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT  nom , mail FROM Entreprise")
                lstmail = cur.fetchall()
        for i in lstmail:
            if(nomm in i ):
                resultat = 1
                return render_template("créent.html",erreur= resultat )
            if(maile in i):
                if(resultat == 1 ):
                    resultat += 1
                    return render_template("créent.html",erreur= resultat )
                else:
                    resultat = 3
                    return render_template("créent.html",erreur= resultat )
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("INSERT INTO Entreprise(nom, sigle,adresse,tel, mail)VALUES(%s,%s,%s,%s,%s)", (nomm ,siglee,adressee,tele,maile))
  
        return render_template("recucreation.html", type= "Entreprise")

def generationlist():
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT nom FROM Entreprise")
            list_entreprise = cur.fetchall()
    for i in range(len(list_entreprise)):
        list_entreprise[i] = (list_entreprise[i])[0]
            
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT nom FROM Association")
            list_association = cur.fetchall()
    for i in range(len(list_association)):
        list_association[i] = (list_association[i])[0]
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT nom FROM Institution")
            list_institution = cur.fetchall()
    for i in range(len(list_institution)):
        list_institution[i] = (list_institution[i])[0]
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT mailpro FROM Contact")
            list_contact = cur.fetchall()
    for i in range(len(list_contact)):
        list_contact[i] = (list_contact[i])[0]
    return list_entreprise , list_association ,list_institution,list_contact    


@app.route("/listepm")
def listepm():
    list_entreprise , list_association ,list_institution,list_contact= generationlist()
        
    return render_template("/listepm.html", list_institution = list_institution , list_association = list_association , list_entreprise =list_entreprise)

@app.route("/pmi")
def pmi():
    list_entreprise , list_association ,list_institution,list_contact= generationlist()
    return render_template("/pmi.html" , list_institution = list_institution , list_association = list_association , list_entreprise =list_entreprise , list_contact = list_contact)

@app.route("/insertpmi")
def insertpmi():
    entreprise = request.args.get("entreprise",None)
    association = request.args.get("association",None)
    institution = request.args.get("institution",None)
    contact = request.args.get("contact",None)
    if (contact =='') or (entreprise == '' and association == '' and institution == ''):
        return redirect(url_for("pmi"))
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO PersonneM(idcontact,ident,idass,idinst)VALUES(%s,%s,%s,%s,%s)", (contact ,entreprise,association,institution))
    
    return redirect(url_for("accueil"))
@app.route("/listepi")
def listepi():
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT mailpro FROM Contact")
            list_mail = cur.fetchall()
    return render_template('/listepi.html',list_mail = list_mail )

@app.route("/supprime")
def supprime():
    entreprise = request.args.get("Entreprise",None)
    association = request.args.get("Association",None)
    institution = request.args.get("Institution",None)
    mail = request.args.get("mail",None)
    if( entreprise != ''):
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"DELETE FROM Entreprise WHERE nom = \'{entreprise}\'")
    if( association != ''):
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"DELETE FROM Association WHERE nom = \'{association}\' ")
    if( institution != ''):
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"DELETE FROM Institution WHERE nom = \'{institution}\' ")
    if( mail != ''):
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"DELETE FROM Contact WHERE mailpro = \'{mail}\' ")
    return redirect(url_for("acceuil"))

@app.route("/créeass")
def créeass():
    return render_template("/créeass.html",erreur = '')


@app.route("/demandeassociation", methods = ['POST'])
def demendeassociation():
    nomm = request.form.get("nom",None)
    print(nomm)
    siglee = request.form.get("sigle",None)
    adressee = request.form.get("adresse",None)
    tele = request.form.get("tel",None)
    maile = request.form.get("mail",None)
    if nomm == '' or siglee == '' or  adressee == '' or  tele == '' or maile == '' :
        resultat= 0
        return render_template("créeass.html",erreur= resultat )
    else:
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT  nom , mail FROM Association")
                lstmail = cur.fetchall()
            for i in lstmail:
                if(nomm in i ):
                    resultat = 1
                    return render_template("créeass.html",erreur= resultat )
                if(maile in i):
                    if(resultat == 1 ):
                        resultat += 1
                        return render_template("créeass.html",erreur= resultat )
                    else:
                        resultat = 3
                        return render_template("créeass.html",erreur= resultat )
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("INSERT INTO Association(nom, sigle, adresse, tel, mail)VALUES(%s,%s,%s,%s,%s)", (nomm ,siglee,adressee,tele,maile))
        return render_template("recucreation.html", type= "Association")



@app.route("/créecon")
def créecon():
    return render_template("/créecon.html",erreur = '')


@app.route("/demendecontact", methods = ['POST'])
def demendecontact():
    nomm = request.form.get("nom",None)
    prenomm= request.form.get("prénom",None)
    adpro = request.form.get("mailpro",None)
    adperso = request.form.get("mailperso",None)
    if nomm == '' or prenomm == '' or  adpro == '' or  adperso == '' :
        resultat= 0
        return render_template("créecon.html",erreur= resultat )
    else:
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT  nom , prenom FROM Contact")
                lstnomprenom = cur.fetchall()
            for i in lstnomprenom:
                if( (nomm,prenomm) == i ):
                    resultat = 1
                    return render_template("créecon.html",erreur= resultat )
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT  mailpro FROM Contact")
                lstmail = cur.fetchall()
            for i in lstmail:
                if(adpro in  i ):
                    return render_template("créecon.html" , erreur = 2)        
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("INSERT INTO Contact(nom,prenom,mailpro,mailperso)VALUES(%s,%s,%s,%s)", (nomm ,prenomm,adpro,adperso))
        return render_template("recucreation.html", type= "Contact")


@app.route("/créeinst")
def créeinst():
    return render_template("/créeinst.html" , resultat= '' )

@app.route("/demandeinstitution", methods = ['POST'])
def demendeinstitution():
    nomm = request.form.get("nom",None)
    adressee = request.form.get("adresse",None)
    siglee = request.form.get("sigle",None)
    typee = request.form.get("type",None)
    if nomm == ''  :
        resultat= 0
        return render_template("créeinst.html",erreur= resultat )
    else:
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT  nom  FROM Institution")
                lstnom = cur.fetchall()
            for i in lstnom:
                if( i == nomm):
                    resultat = 1
                    return render_template("créeinst.html",erreur= resultat )     
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("INSERT INTO Contact(nom,adresse,sigle,type)VALUES(%s,%s,%s,%s)", (nomm ,adressee,siglee,typee))
        return render_template("recucreation.html", type= "Insitution")

@app.route("/accueil")
def accueil():
    return render_template("/accueil.html")
@app.route("/")
def main():
    return accueil()

@app.route("/utilisateur")
def utilisateur():
    return render_template("/utilisateur.html")


   # creation d'un mots de passe
@app.route("/créemdp")
def créemdp():
    return render_template("/créemdp.html" , erreur = '')


def misajour(type, maile ,mdp ,bool):
    with db.connect() as conn:
        with conn.cursor() as cur:
            if(bool):
                cur.execute(f"SELECT mail,mdp FROM {type} ")
            else:
                cur.execute(f"SELECT mailpro,mdp FROM {type} ")
            lstmail = cur.fetchall()
    for i in lstmail:
        if(maile in i):
            if(i[1] == None ):
                password_ctx = CryptContext(schemes=['bcrypt'])
                hash_pw = password_ctx.hash(mdp)
                with db.connect() as conn:
                    with conn.cursor() as cur:
                        if(bool):
                            cur.execute(f"UPDATE {type } SET mdp = \'{hash_pw }\' WHERE mail =\'{maile}\'")
                        else : 
                            cur.execute(f"UPDATE {type } SET mdp = \'{hash_pw }\' WHERE mailpro =\'{maile}\'")
                return True
            else:
                return False
    return None
@app.route("/créationmdp" , methods= ['POST'])
def créationmdp():
    maile = request.form.get("mail",None)
    mdp = request.form.get("mdp",None)
    tmp = True
    for i in lstype :
        if(i == 'Contact'):
            tmp = False
        bool = misajour(i,maile,mdp,tmp)
        if(bool):
            return redirect(url_for('utilisateur'))
        elif(bool == False):
            return render_template("/créemdp.html",erreur = 1 )
    return render_template("/créemdp.html",erreur = 2 )

    # connexion 
@app.route("/connexion")
def connexion():
    return render_template("/connexion.html" , erreur = '')

def verifconnexion(type , maile ,mdp ,bool):
    boole = False
    boole1 = False
    with db.connect() as conn:
        with conn.cursor() as cur:
            if(bool):
                cur.execute(f"SELECT mail FROM {type} ")
            else:
                cur.execute(f"SELECT mailpro FROM {type} ")
            lstmail = cur.fetchall()
    for i in lstmail:
        if(maile in  i):
            boole1 = True
            with db.connect() as conn:
                with conn.cursor() as cur:
                    if(bool):
                        cur.execute(f"SELECT mdp FROM {type} WHERE mail =\'{maile}\' ")
                    else:
                        cur.execute(f"SELECT mdp FROM {type} WHERE mailpro =\'{maile}\' ")
                    mdpe = cur.fetchall()
                    print(mdpe,mdpe[0])
                    password_ctx = CryptContext(schemes=['bcrypt'])
                    boole = password_ctx.verify(mdp, mdpe[0][0])
                print(bool)
                print(mdp)  # test à effectuer au login de l'utilisateur
    if(not(boole1)):
        return(None ,None) #l'adresse mail n'est pas dans la base
    if(boole):
        return(maile ,type)
    return (False,False) # mots de passe n'est pas le bon


@app.route("/verificationconnexion" , methods= ['POST'])
def verficationconnexion():
    maile = request.form.get("mail",None)
    mdp = request.form.get("mdp",None)
    tmp = True
    for i in lstype :
        if(i == 'Contact'):
            tmp = False
        mail,type = verifconnexion(i,maile,mdp,tmp)
        if(mail != False ) and ( mail != None):
            if(type == 'Entreprise'):
                with db.connect() as conn:
                    with conn.cursor() as cur:
                        cur.execute(f"SELECT IdEnt FROM Entreprise WHERE mail = '{mail}'")
                        ident = cur.fetchone()[0]
                        session["id"] = ident
                return redirect(url_for("profileent"))
            elif(type == 'Association'):
                with db.connect() as conn:
                    with conn.cursor() as cur:
                        cur.execute(f"SELECT IdAss FROM Association WHERE mail = '{mail}'")
                        idass = cur.fetchone()[0]
                        session["id"] = idass
                return redirect(url_for("profileassociation"))
            elif(type == 'Insitution'):
                with db.connect() as conn:
                    with conn.cursor() as cur:
                        cur.execute(f"SELECT IdInst FROM Institution WHERE mail = '{mail}'")
                        idinst = cur.fetchone()[0]
                        session["id"] = idinst
                return redirect(url_for("profileinstitution"))
            else:
                with db.connect() as conn:
                    with conn.cursor() as cur:
                        cur.execute(f"SELECT Idcontact FROM Contact WHERE mailpro = '{mail}'")
                        idcontact = cur.fetchone()[0]
                        session["id"] = idcontact
                return redirect(url_for("profilecontact"))

        elif(mail == False):
            return render_template("/connexion.html", erreur = 1 ) # mots de passe incorrect
    return render_template("/connexion.html", erreur = 2 )

@app.route("/profilecontact")
def profilecontact():
    if "id" in session :
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT nom, prenom FROM contact WHERE idcontact = %s", (session['id'],))
                lst = cur.fetchall()
            nom = lst[0][0]
            prenom =lst[0][1]
        return render_template("/profilecontact.html", nom = nom ,prenom = prenom)
    return redirect(url_for("connexion"))

@app.route("/profileent")
def profileent():
    if "id" in session :
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT nom FROM entreprise WHERE ident = %s", (session['id'],))
                lst = cur.fetchall()
            nom = lst[0][0]
        return render_template("/profileent.html",nom = nom)
    return redirect(url_for("connexion"))

@app.route("/profileinstitution")
def profileinstitution():
    if "id" in session :
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT nom FROM institution WHERE idinst = %s", (session['id'],))
                lst = cur.fetchall()
            nom = lst[0][0]
        return render_template("/profileinstitution.html",nom = nom)
    return redirect(url_for("connexion"))

@app.route("/profileassociation")
def profileassociation():
    if "id" in session :
        with db.connect() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT nom FROM association WHERE idass = %s", (session['id'],))
                lst = cur.fetchall()
            nom = lst[0][0]
        return render_template("/profileassociation.html",nom=nom)
    return redirect(url_for("connexion"))

@app.route("/deconnexion")
def deconnexion():
  if "id" in session:
    session.pop("id")
  return redirect(url_for("connexion"))

# autres
@app.route("/cotisation")
def cotisation():
    return render_template("/cotisation.html",erreur = 0)



@app.route("/inserationcotisation",methods= ['POST'])
def inserationcotisation():
    datepaiment = datetime.date(2022 ,12, 15)
    nb = request.form.get("nombre",None)
    ca = request.form.get("ca",None)
    if( datepaiment != datetime.date.today()):
        return render_template("/cotisation.html",erreur = 1 )
    if( nb == '' or ca == '' ):
        return render_template("/cotisation.html",erreur = 2 )
    # calcule du montant de la cotisation
    if(int(nb) <50):
        montant = 0.012 * int(ca)
    else:
        tmp = int(nb) //50
        montant = (0.012 + (0.5 * tmp)) * int(ca) 
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO Cotisation(montant,nbmembre,IdAss)VALUES(%s,%s,%s)", (montant,nb,session['id']))    
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO Historique(CA,IdAss,date)VALUES(%s,%s,%s)", (ca,session['id'],datepaiment))
    return render_template("/cotisation.html",erreur = 3 , montant = montant )
    



@app.route("/activite")
def activite():
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT nom, categorie, dtdebut, dtfin FROM activité ORDER BY dtfin DESC")
            lstact = cur.fetchall()
    return render_template("/activite.html", lstact = lstact)

@app.route("/admin")
def admin():
    return render_template("/connexion_admin.html")

@app.route("/verificationadmin", methods = ['POST'])
def verificationadmin():
    mdp = request.form.get("mdp",None)
    if mdp == "admin":
        return render_template("/acceuil.html")
    return render_template("/accueil.html")

@app.route("/deco")
def deco():
    return render_template("/accueil.html")

@app.route("/creerlettre")
def creerlettre():
    return render_template("/creerlettre.html")


@app.route("/insertlettre", methods = ['POST'])
def insertlettre():
    lettree = request.form.get("lettre",None)
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO Lettre(texte)VALUES( %s )",(lettree,))
    return render_template("/acceuil.html")

@app.route("/distribuer")
def distribuer():
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT IdLt from Lettre ")
            lstid = cur.fetchall()
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT mailpro from contact ")
            mailpro = cur.fetchall()
    return render_template("/distribuer.html", lstid = lstid, mailpro = mailpro)

@app.route("/distribution")
def distribution():
    id = request.args.get("id",None)
    maile = request.args.get("maile",None)
    dt = datetime.date.today()
    if(id == '' or maile == ''):
        return redirect(url_for('distribuer'))
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT idcontact from contact where mailpro = %s", (maile,))
            idcontact = cur.fetchone()[0]
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT idcontact from distribution where idlt = %s AND idcontact = %s", (id,idcontact))
            tmp = cur.fetchone()
    if tmp != None:
            return redirect(url_for('distribuer'))
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"INSERT INTO distribution VALUES (%s, %s, '{dt}')", (id, idcontact))

    return redirect(url_for('acceuil'))


@app.route("/creeact")
def creeact():
    return render_template("/creeact.html")

@app.route("/insertact", methods=['POST'])
def insertact():
    nom = request.form.get("nom",None)
    categorie = request.form.get("categorie",None)
    dtdebut = request.form.get("dtdebut",None)
    dtfin = request.form.get("dtfin",None)
    if(nom == '' or categorie ==''):
        return render_template("/creeact.html",erreur = 0)
    if(dtdebut>dtfin):
        return render_template("/creeact.html",erreur = 1)
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"INSERT INTO activité (nom, categorie, dtdebut, dtfin) VALUES (%s, %s, '{dtdebut}', '{dtfin}')", (nom, categorie))

    return redirect(url_for('acceuil'))


@app.route("/donation")
def donation():
    if( 'id' not in session):
        return redirect(url_for('connexion'))
    return render_template("/donation.html")

@app.route("/ajoutdonation", methods=['POST'])
def ajoutdonation():
    montant = request.form.get("montant",None)
    if(montant == ''):
        return render_template('/donation.html' , erreur = 1)
    dt = datetime.date.today()
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"INSERT INTO don (montant) VALUES ( %s)", (montant,))
            cur.execute("SELECT iddon FROM don ORDER BY iddon DESC LIMIT 1")
            iddon = cur.fetchone()[0]
            cur.execute(f"INSERT INTO versement (Iddon, IdContact, date) VALUES ( %s, %s, '{dt}')", (iddon, session["id"]))

    return redirect(url_for('profilecontact'))

@app.route("/voirdonation")
def voirdonation():
    if( 'id' not in session):
        return redirect(url_for('connexion'))
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT nom, prenom, montant,date FROM contact NATURAL JOIN versement NATURAL JOIN don where idcontact = '{session['id']}' ORDER BY date DESC")
            lstdon = cur.fetchall()
    return render_template("/voirdonation.html", lstdon = lstdon )


@app.route("/message")
def message():
    if( 'id' not in session):
        return redirect(url_for('connexion'))
    with db.connect() as conn:
        with conn.cursor() as cur:
            ide = session['id'] #j'arrive juste pas a la mettre directement avec ''
            cur.execute(f"SELECT texte FROM lettre NATURAL JOIN distribution where idcontact = \'{ide} \' ")
            lstmessage = cur.fetchall()
    if(len(lstmessage) == 0):
        erreur = 0
    erreur = 1
    return render_template('/message.html',lstmessage =lstmessage,erreur = erreur)

@app.route("/participation")
def participation():
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT Idact from activité ")
            lstact = cur.fetchall()
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT mailpro from contact ")
            mailpro = cur.fetchall()
    return render_template("/participation.html", lstact = lstact, mailpro = mailpro)

@app.route("/insertparticipation")
def insertparticipation():
    idact = request.args.get("id",None)
    maile = request.args.get("maile",None)
    
    if(id == '' or maile == ''):
        return redirect(url_for('participation'))
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT idcontact from contact where mailpro =  \'{maile}\'")
            idcontact = cur.fetchone()
            
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT idact from participation where idact = %s AND idcontact = %s", (idact,idcontact))
            tmp = cur.fetchone()
    if tmp != None:
            return redirect(url_for('acceuil'))
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"INSERT INTO participation VALUES (%s, %s)", (idact, idcontact))

    return redirect(url_for('acceuil'))

@app.route("/subvention")
def subvention():
    if( 'id' not in session):
        return redirect(url_for('connexion'))
    return render_template("/subvention.html")

@app.route("/ajoutsubvention", methods=['POST'])
def ajoutsubvention():
    montant = request.form.get("montant",None)
    if(montant == ''):
        return render_template('/subvention.html' , erreur = 1)
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT nom from entreprise where ident = \'{session['id']}\'")
            nom = cur.fetchone()
    dt = datetime.date.today()
    with db.connect() as conn:
        with conn.cursor() as cur:
            if(nom == None):
                cur.execute(f"INSERT INTO subvention (montant, date, idinst) VALUES ( %s, '{dt}',%s)", (montant, session["id"]))
                return redirect(url_for('profileinstitution'))
            else:
                cur.execute(f"INSERT INTO subvention (montant, date, ident) VALUES ( %s, '{dt}',%s)", (montant, session["id"]))
                return redirect(url_for('profileent'))
@app.route("/historique")
def historique():
    if( 'id' not in session):
        return redirect(url_for('connexion'))
    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT CA, date FROM historique where idass = %s ORDER BY date DESC", (session['id'],))
            lsthisto = cur.fetchall()

    with db.connect() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT montant, nbmembre FROM cotisation where idass = %s ORDER BY idcot DESC", (session['id'],))
            lst_montant_nbm = cur.fetchall()
    return render_template("/historique.html", lsthisto = lsthisto, lst_montant_nbm = lst_montant_nbm)

if __name__ == '__main__':
    app.run()
