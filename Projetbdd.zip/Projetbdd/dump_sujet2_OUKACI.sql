--


--
-- Create table Contact
--
DROP TABLE IF EXISTS Contact CASCADE;
DROP TABLE IF EXISTS Association CASCADE;
DROP TABLE IF EXISTS Entreprise CASCADE;
DROP TABLE IF EXISTS Institution CASCADE;
DROP TABLE IF EXISTS PersonneM CASCADE;
DROP TABLE IF EXISTS Cotisation CASCADE;
DROP TABLE IF EXISTS Historique CASCADE;
DROP TABLE IF EXISTS Distribution CASCADE;
DROP TABLE IF EXISTS Activité CASCADE;
DROP TABLE IF EXISTS Participation CASCADE;
DROP TABLE IF EXISTS Don CASCADE;
DROP TABLE IF EXISTS Versement CASCADE;
DROP TABLE IF EXISTS Lettre CASCADE;
DROP TABLE IF EXISTS Subvention CASCADE;
CREATE TABLE Contact (
	IdContact serial primary key,
	 nom varchar(25) not null,
	 prenom varchar(25) not null,
	 mailpro varchar(50) Unique,
	 mailperso varchar(50) Unique,
	 mdp  varchar(200),
	 CONSTRAINT uniqueNomPrenom UNIQUE (nom,prenom)
);

--
-- Create table Entreprise
--

CREATE TABLE Entreprise (
	IdEnt serial primary key,
	nom varchar(50) not null UNIQUE,
	sigle varchar(20),
	adresse text not null,
	Tel varchar(10),
	mail varchar(50) Unique,
	mdp  varchar(200)
);

--
-- Create table Association
--

CREATE TABLE Association (
	IdAss serial primary key ,
	nom varchar(100) not null UNIQUE ,
	sigle varchar(20),
	adresse text not null,
	Tel varchar(10),
	mail varchar(50) Unique,
	mdp  varchar(200)
);

-- Create table Institution
CREATE TABLE Institution (
	IdInst serial primary key ,
	nom varchar(50) not null UNIQUE ,
	adresse text ,
	sigle varchar(20),
	type varchar(20),
	mail varchar(50),
	mdp  varchar(200)
);

--
-- Create table PersonneM
--

CREATE TABLE PersonneM (
	IdPm serial primary key,
	IdContact integer NOT NULL,
	IdEnt integer ,
	IdInst integer ,
	IdAss integer ,
	FOREIGN KEY (IdContact) REFERENCES Contact(IdContact)
	ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (IdEnt) REFERENCES Entreprise(IdEnt)
	ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (IdInst) REFERENCES Institution(IdInst)
	ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (IdAss) REFERENCES Association(IdAss)
	ON DELETE CASCADE ON UPDATE CASCADE,
	CHECK (IdEnt is not NULL OR  IdInst is not NULL OR IdAss is not NULL)
);


-- Create table Cotisation
CREATE TABLE Cotisation (
	IdCot serial primary key ,
	montant INTEGER not null,
	nbmembre INTEGER not null,
	IdAss integer not null,
	FOREIGN KEY (IdAss) REFERENCES Association(IdAss)
	ON DELETE CASCADE ON UPDATE CASCADE
);
-- Create table Historique
CREATE TABLE Historique (
	IdHis serial primary key ,
	CA INTEGER not null,
	IdAss integer,
	date date not null,
	FOREIGN KEY (IdAss) REFERENCES Association(IdAss)
	ON DELETE CASCADE ON UPDATE CASCADE
);

-- Create table Subvention
CREATE TABLE Subvention (
	Idsub serial primary key ,
	montant int not null,
	remarque text ,
	date DATE not null,
	IdEnt integer ,
	IdInst integer,
	FOREIGN KEY (IdEnt) REFERENCES Entreprise(IdEnt)
	ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (IdInst) REFERENCES Institution(IdInst)
	ON DELETE CASCADE ON UPDATE CASCADE,
	CHECK (IdEnt is not NULL OR  IdInst is not NULL)
);
--Create table lettre
CREATE TABLE Lettre (
	IdLt serial primary key ,
	texte text not null
);
--Create table Distribution
CREATE TABLE Distribution (
	IdLt INTEGER ,
	IdContact integer,
	date date not null,
	PRIMARY KEY (IdLt,IdContact),
	FOREIGN KEY (IdContact) REFERENCES Contact(IdContact)
	ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (IdLt) REFERENCES Lettre(IdLt)
	ON DELETE CASCADE ON UPDATE CASCADE

);
--Create table Activité
CREATE TABLE Activité (
	IdAct serial primary key ,
	nom varchar(100) not null,
	categorie varchar(25) not null,
	dtdebut date,
	dtfin date ,
	CONSTRAINT intervale CHECK (dtdebut <= dtfin)
);

-- CREATE table Participation
CREATE TABLE Participation (
	IdAct integer ,
	IdContact integer,
	PRIMARY KEY (IdAct,IdContact),
	FOREIGN KEY (IdAct) REFERENCES Activité(IdAct)
	ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (IdContact) REFERENCES Contact(IdContact)
	ON DELETE  CASCADE ON UPDATE CASCADE

);
--Create Table Don
CREATE TABLE Don  (
	IdDon serial primary key ,
	Montant integer not null
);
-- Create table Versement

CREATE TABLE Versement (
	IdDon integer ,
	IdContact integer,
	date date not null,
	PRIMARY KEY (IdDon,IdContact),
	FOREIGN KEY (IdContact) REFERENCES Contact(IdContact)
	ON DELETE CASCADE ON UPDATE CASCADE,
	FOREIGN KEY (IdDon) REFERENCES Don(IdDon)
	ON DELETE  CASCADE ON UPDATE CASCADE

);



-- Exemples de données
-- en commentaires des exemples de contraintes qui ont eté reussite


INSERT INTO Contact(nom, prenom, mailpro, mailperso)VALUES ('Oukaci', 'Rayan', 'Rayan.mailpro@gmail.com', 'Rayan.mailperso@gmail.com');
INSERT INTO Contact(nom, prenom, mailpro, mailperso)VALUES ('Marchand', 'Florian', 'Florian.mailpro@gmail.com', 'Florian.mailperso@gmail.com');
INSERT INTO Contact(nom, prenom, mailpro, mailperso)VALUES ('Smith', 'Leah', 'Leah.mailpro@gmail.com', 'Leah.mailperso@gmail.com');
INSERT INTO Contact(nom, prenom, mailpro, mailperso)VALUES ('Lapierre', 'Pierre', 'Pierre.mailpro@gmail.com', 'Pierre.mailperso@gmail.com');
INSERT INTO Contact(nom, prenom, mailpro, mailperso) VALUES ('Auneau','Pierre-Alexis','AuneauPierre-Alexispro@gmail.com','AuneauPierre-Alexis0@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES (' Heleine','Abdelaziz','HeleineAbdelazizpro@gmail.com','HeleineAbdelaziz0@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Schipper','Niels','SchipperNielspro@gmail.com','SchipperNiels1@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Noizet','Lydie','NoizetLydiepro@gmail.com','NoizetLydie2@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Collina','Mariana','CollinaMarianapro@gmail.com','CollinaMariana3@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Browning','William','BrowningWilliampro@gmail.com','BrowningWilliam4@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Santiago','Ashley','SantiagoAshleypro@gmail.com','SantiagoAshley5@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Brenet','Mélanie','BrenetMélaniepro@gmail.com','BrenetMélanie6@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Binaghi','Filippa','BinaghiFilippapro@gmail.com','BinaghiFilippa7@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Gönül','Dr.','GönülDr.pro@gmail.com','GönülDr.8@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Morcillo','Aline','MorcilloAlinepro@gmail.com','MorcilloAline9@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Echevarría','Reinaldo','EchevarríaReinaldopro@gmail.com','EchevarríaReinaldo10@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Nivault','Safir','NivaultSafirpro@gmail.com','NivaultSafir11@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Lafforgue','Dante','LafforgueDantepro@gmail.com','LafforgueDante12@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Santi','Ania','SantiAniapro@gmail.com','SantiAnia13@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Salomez','Jean-Charles','SalomezJean-Charlespro@gmail.com','SalomezJean-Charles14@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Ducarre','Leïla','DucarreLeïlapro@gmail.com','DucarreLeïla15@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Averous','Yassir','AverousYassirpro@gmail.com','AverousYassir16@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Curtis','Jennifer','CurtisJenniferpro@gmail.com','CurtisJennifer17@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Audet','Hiba','AudetHibapro@gmail.com','AudetHiba18@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Wieczorek','Patrick','WieczorekPatrickpro@gmail.com','WieczorekPatrick19@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Foucault','Hassan','FoucaultHassanpro@gmail.com','FoucaultHassan20@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Dervaux','Neil','DervauxNeilpro@gmail.com','DervauxNeil21@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Braban','Arthur','BrabanArthurpro@gmail.com','BrabanArthur22@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Bucamp','Léone','BucampLéonepro@gmail.com','BucampLéone23@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Dubeau','Razane','DubeauRazanepro@gmail.com','DubeauRazane24@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Nectoux','Cristina','NectouxCristinapro@gmail.com','NectouxCristina25@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES (' Fievre','Josephe','FievreJosephepro@gmail.com','FievreJosephe26@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Obrien','Beth','ObrienBethpro@gmail.com','ObrienBeth27@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Brocq','Mokhtar','BrocqMokhtarpro@gmail.com','BrocqMokhtar28@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Gieß','Franz-Peter','GießFranz-Peterpro@gmail.com','GießFranz-Peter29@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Gruet','Mariano','GruetMarianopro@gmail.com','GruetMariano30@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Wright','Adam','WrightAdampro@gmail.com','WrightAdam31@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Martens','Puk','MartensPukpro@gmail.com','MartensPuk32@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Chauchard','François','ChauchardFrançoispro@gmail.com','ChauchardFrançois33@gmail.com' );
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES (  'Lamaud','Ourida','LamaudOuridapro@gmail.com','LamaudOurida35@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Dages','Melyne','DagesMelynepro@gmail.com','DagesMelyne36@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Carpio','Benigno','CarpioBenignopro@gmail.com','CarpioBenigno37@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Marie-Luise','Dr.','Marie-LuiseDr.pro@gmail.com','Marie-LuiseDr.38@gmail.com');
INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ( 'Schuchhardt','Ekkehart','SchuchhardtEkkehartpro@gmail.com','SchuchhardtEkkehart39@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Gibson','Philip','GibsonPhilippro@gmail.com','GibsonPhilip40@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Ball','Jessica','BallJessicapro@gmail.com','BallJessica41@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Borsiere','Nadia','BorsiereNadiapro@gmail.com','BorsiereNadia42@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Jones','Laura','JonesLaurapro@gmail.com','JonesLaura43@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Ganne','Sidonie','GanneSidoniepro@gmail.com','GanneSidonie44@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Zurita','Candelas','ZuritaCandelaspro@gmail.com','ZuritaCandelas45@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Bigaud','Nassim','BigaudNassimpro@gmail.com','BigaudNassim46@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Kueny','Tyana','KuenyTyanapro@gmail.com','KuenyTyana47@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Fenouil','Halil','FenouilHalilpro@gmail.com','FenouilHalil48@gmail.com');
 INSERT INTO Contact(nom,prenom,mailpro,mailperso) VALUES ('Rachael','Dr','RachaelDrpro@gmail.com','RachaelDr49@gmail.com');





INSERT INTO Activité (nom, categorie,dtdebut,dtfin)VALUES ('cinema', 'documentaire', '2022-06-12', '2022-06-12');
INSERT INTO Activité (nom, categorie,dtdebut,dtfin)VALUES ('cinema', 'documentaire', '2022-06-12', '2022-06-12');
--INSERT INTO Activité (nom, categorie,dtdebut,dtfin)VALUES ('Seance de cinema', 'Documentaire', '2022-06-12', '2022-06-11'); ne passe pas !!
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('cinema', 'documentaire', '2020-05-12', '2020-05-12');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('cinema', 'documentaire', '2021-10-23', '2021-10-23');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('musee', 'documentaire', '2021-02-04', '2021-02-04');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('musee', 'documentaire', '2022-07-09', '2022-07-09');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('football', 'sport', '2019-06-14', '2019-06-14');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('Handball', 'sport', '2020-11-20', '2020-11-20');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('Tenis', 'sport', '2021-05-17', '2021-05-17');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('Yoga', 'sport', '2021-08-29', '2021-08-29');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('Yoga', 'sport', '2022-10-03', '2022-10-03');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('fitness', 'sport', '2021-09-15', '2021-09-15');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('fitness', 'sport', '2022-10-17', '2022-10-17');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('parachute', 'sport', '2018-01-05','2018-01-07');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('pique-nique', 'detente', '2021-07-12', '2021-07-12');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('pique-nique', 'detente', '2022-07-16', '2022-07-16');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('poker', 'detente', '2020-04-01', '2020-04-01');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('escape game', 'detente', '2021-06-06', '2021-06-06');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('escape game', 'detente', '2022-06-21', '2022-06-21');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('escape game', 'detente', '2022-09-09', '2022-09-09');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('Karaoke', 'detente', '2020-05-11', '2020-05-11');
INSERT INTO Activité(nom, categorie, dtdebut,dtfin)VALUES('Karaoke', 'detente', '2021-05-20', '2021-05-20');



INSERT INTO Participation VALUES (1, 1);
INSERT INTO Participation VALUES (2, 1);
INSERT INTO Participation VALUES (2, 2);
INSERT INTO Participation VALUES (1, 4);
INSERT INTO participation VALUES (4, 3);
INSERT INTO participation VALUES (6, 3);
INSERT INTO participation VALUES (10, 3);
INSERT INTO participation VALUES (20, 3);

INSERT INTO participation VALUES (5, 4);
INSERT INTO participation VALUES (18, 4);
INSERT INTO participation VALUES (20, 4);

INSERT INTO participation VALUES (1, 6);
INSERT INTO participation VALUES (15, 6);
INSERT INTO participation VALUES (20, 6);

INSERT INTO participation VALUES (12, 10);
INSERT INTO participation VALUES (19, 10);
INSERT INTO participation VALUES (20, 10);

INSERT INTO participation VALUES (14, 11);
INSERT INTO participation VALUES (13, 11);
INSERT INTO participation VALUES (19, 11);

INSERT INTO participation VALUES (3, 13);
INSERT INTO participation VALUES (4, 13);
INSERT INTO participation VALUES (19, 13);

INSERT INTO participation VALUES (16, 15);
INSERT INTO participation VALUES (18, 15);
INSERT INTO participation VALUES (20, 15);

INSERT INTO participation VALUES (8, 20);
INSERT INTO participation VALUES (10, 20);
INSERT INTO participation VALUES (15, 20);
INSERT INTO participation VALUES (20, 20);


INSERT INTO Don (montant)VALUES (1);
INSERT INTO Don (montant)VALUES (5);
INSERT INTO Don (montant)VALUES (10);
INSERT INTO Don (montant)VALUES (50);
INSERT INTO Don (montant)VALUES (100);
INSERT INTO Don (montant)VALUES (200);
INSERT INTO Don (montant)VALUES (500);
INSERT INTO Don (montant)VALUES (1000);
INSERT INTO Don (montant)VALUES (5000);
INSERT INTO Don (montant)VALUES (10000);


INSERT INTO Versement(idDon, idcontact, date)VALUES (1, 1, '2020-08-15');
INSERT INTO Versement(idDon, idcontact, date)VALUES (2, 1, '2021-10-01');
INSERT INTO Versement(idDon, idcontact, date)VALUES (2, 2, '2022-04-25');
INSERT INTO Versement(idDon, idcontact, date)VALUES (3, 4, '2022-05-09');
--INSERT INTO Versement(idDon, idcontact, date)VALUES (3, 5, '2022-05-09'); passe pas
INSERT INTO Versement(idDon, idcontact, date)VALUES (5, 10, '2020-08-15');
INSERT INTO Versement(idDon, idcontact, date)VALUES (2, 7, '2021-08-15');
INSERT INTO Versement(idDon, idcontact, date)VALUES (4, 5, '2022-08-15');
INSERT INTO Versement(idDon, idcontact, date)VALUES (8, 15, '2020-02-19');
INSERT INTO Versement(idDon, idcontact, date)VALUES (6, 17, '2021-02-19');
INSERT INTO Versement(idDon, idcontact, date)VALUES (7, 16, '2022-02-19');
INSERT INTO Versement(idDon, idcontact, date)VALUES (10, 1, '2021-04-14');
INSERT INTO Versement(idDon, idcontact, date)VALUES (5, 2, '2022-04-14');
INSERT INTO Versement(idDon, idcontact, date)VALUES (7, 20, '2020-10-29');
INSERT INTO Versement(idDon, idcontact, date)VALUES (6, 25, '2021-10-29');
INSERT INTO Versement(idDon, idcontact, date)VALUES (4, 30, '2022-10-29');
INSERT INTO Versement(idDon, idcontact, date)VALUES (5, 11, '2020-08-15');
INSERT INTO Versement(idDon, idcontact, date)VALUES (2, 14, '2021-08-15');
INSERT INTO Versement(idDon, idcontact, date)VALUES (4, 7, '2022-08-15');
INSERT INTO Versement(idDon, idcontact, date)VALUES (6, 16, '2020-02-19');
INSERT INTO Versement(idDon, idcontact, date)VALUES (6, 12, '2021-02-19');
INSERT INTO Versement(idDon, idcontact, date)VALUES (8, 30, '2022-02-19');
INSERT INTO Versement(idDon, idcontact, date)VALUES (3, 31, '2021-04-14');
INSERT INTO Versement(idDon, idcontact, date)VALUES (5, 34, '2022-04-14');
INSERT INTO Versement(idDon, idcontact, date)VALUES (4, 40, '2020-10-29');
INSERT INTO Versement(idDon, idcontact, date)VALUES (6, 37, '2021-10-29');
INSERT INTO Versement(idDon, idcontact, date)VALUES (4, 36, '2022-10-29');




INSERT INTO Association (nom,sigle, adresse, tel, mail)VALUES ('ASSOC1', 'A1', '24 Rue de Ségur', '0101010199', 'Asoc1_24@gmail.com');
INSERT INTO Association (nom,sigle, adresse, tel, mail)VALUES ('ASSOC2', 'A2', '38 Rue Duquesne', '0101010189', 'Asoc2_38@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Association Les doigts qui rêvent','At','4 boulevard de Guilbert 89809 Reynauddan','0773779963','Lesdoigtsquirêvent@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Les rigollots','Ls','54 avenue Aubert 70308 Lopes','0179637875','Lesrigollots@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Association française des intolérants au gluten','An','57 rue Rolland 40958 Roux-la-Forêt','0352673759','intolérantsaugluten@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Association Société Nationale de Sauvetage en Mer','Ar','71 rue de Ramos 40023 Gomes-la-Forêt','0734487437','SauvetageenMer@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Française des Solo','Fo','78 avenue Pascal 06108 RoyBourg','0334267753','FrançaisedesSolo@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Association Pour Un Meilleur Arbitrage dans le football','Al','743 boulevard Besnard 32079 Danielnec','0782487358','Arbitragefootball@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Africains sans papiers','As','37 boulevard Maillet 27883 Hernandez','0989792673','Africainssanspapiers@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Association Société Nationale de Sauvetage en Air','Ar','79 boulevard De Oliveira 34771 Gay-la-Forêt','0445395453','SauvetageenAir@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Métro aux rigollots','Ms','8 boulevard Philippe Martins 35462 Menardnec','0394718893',' Métroauxrigollots@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Métro aux evadés','Ms','9 rue de Dumas 16503 Simondan','0511574816',' Métroauxevadés@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Association de l''ostéogénèse imparfaite','Ae','987 boulevard Élodie Guyot 58969 LombardVille','0783384162','ostéogénèseimparfaite@gmail.com');
INSERT INTO Association(nom,sigle,adresse,tel,mail) VALUES('Association La Gerbe','Ae','586 boulevard de Marchand 69194 Royer','0839187283','LaGerbe@gmail.com');



INSERT INTO Historique (idAss, CA, date)VALUES (1, 100000, '2020-12-21');
INSERT INTO Historique (idAss, CA, date)VALUES (2, 500000, '2021-12-29');
INSERT INTO Historique (idAss, CA, date)VALUES (1, 75000, '2021-12-19');
--INSERT INTO Historique (idAss, CA)VALUES (2, 600000); /*Ne passe pas*/

INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (1, 1700, 50);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (2, 11000,100);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (1, 900,40);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (4, 600, 20);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (5, 1900, 70);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (6, 300, 25);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (7, 1700, 50);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (8, 2000, 100);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (9, 1550, 75);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (10, 2300, 200);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (11, 1900, 120);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (12, 2200, 155);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (13, 700, 35);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (14, 1200, 65);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (4, 500, 25);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (10, 2450, 255);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (11, 2000, 150);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (4, 600, 20);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (5, 1900, 70);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (6, 300, 25);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (7, 1700, 50);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (8, 2000, 100);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (9, 1550, 75);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (10, 2300, 200);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (11, 1900, 120);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (12, 2200, 155);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (13, 700, 35);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (14, 1200, 65);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (4, 500, 25);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (10, 2450, 255);
INSERT INTO Cotisation (idAss, montant, nbmembre)VALUES (11, 2000, 150);




INSERT INTO Lettre (texte)VALUES ('Ceci est une lettre pouvant etre distribué a tous les contact individuel.');
INSERT INTO Lettre (texte)VALUES ('Ceci est une lettre spécialement pour ce contact individuel ');

INSERT INTO Distribution (idLt, idcontact, date)VALUES (1, 1,'2022-01-05');
INSERT INTO Distribution (idLt, idcontact, date)VALUES (1, 2, '2022-01-05');
INSERT INTO Distribution (idLt, idcontact, date)VALUES (1, 3,'2022-01-05');
INSERT INTO Distribution (idLt, idcontact, date)VALUES (2, 4,'2022-01-15');


INSERT INTO Entreprise(nom, sigle, adresse, tel, mail)VALUES ('Ent1', 'E1', '6 Rue ici', '0404040499', 'Ent1_6@gmail.com');
INSERT INTO Entreprise(nom, sigle, adresse, tel, mail)VALUES ('Ent2', 'E2', '54 Rue la-bas', '0404040425', 'Ent2_54@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Leaderhigh','Lh','50 avenue Rivière, 51995 Gosselin','0461764322','Leaderhigh@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Vitaprofessional','Vl','4 avenue de Nguyen 19670, Lejeune','0465626647','Vitaprofessional@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'The Car Group','Tp','134 avenue Diane Leduc 95881 Charles','0238654959','The Car Group@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Trillteam','Tm','89 rue Sauvage 63988 Turpinnec','0915853949','Trillteam@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Electraall','El','15 chemin de Chauveau 59469, Guillot-sur-Mer','0714944658','Electraall@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Enginecafe','Ee','538 chemin Maillet 70024 Schneider-sur-Mer','0659914449','Enginecafe@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Wowstep','Wp','7 avenue de Courtois 07046 Menard','0628133343','Wowstep@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Carroch','Ch','922 rue de Barre 70075 Roussel','0115245155','Carroch@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Nuelectra','Na','48 rue Vincent Léger 90185 Morin','0748789765','Nuelectra@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Hubwood','Hd','19 rue Marques 88361 Saint Adélaïde','0565855475','Hubwood@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Firstwiz','Fz','24 boulevard Hélène Toussaint 37576 Sainte Robert','0142942811','Firstwiz@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Softdude','Se','74 boulevard René Bonnin 47101 Benoit','0863155961','Softdude@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Tidaprofessional','Tl','485 chemin Élise Robert 23584 Peltier','0519379919','Tidaprofessional@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Primalteam','Pm','52 avenue Michelle Devaux 52519 Thibault-sur-Grégoire','0324323833','Primalteam@gmail.com');
INSERT INTO Entreprise(nom,sigle,adresse,tel,mail) VALUES( 'Prokf','Pf','701 avenue de Labbé 35464 Courtoisnec','0389263435','Prokf@gmail.com');


INSERT INTO Institution(nom,sigle, adresse, type)VALUES ('Ministere de la culture', 'MC', '83 Rue connu', 'Culture');
INSERT INTO Institution(nom,sigle,adresse,type) VALUES('Ministere de l"Economie','ME','54 rue Xavier Boulay 07809 Bessonboeuf','Economie');
INSERT INTO Institution(nom,sigle,adresse,type) VALUES('Ministere de la Finance','MF',' 2 chemin Andre 01921 Saint Louis','Finance');
INSERT INTO Institution(nom,sigle,adresse,type) VALUES('Ministere de la justice' ,'MJ', '139 rue Robert Lebon 87492 ToussaintBourg','Justice');
INSERT INTO Institution(nom,sigle,adresse,type) VALUES('Ministere de l"Armées','MA' , '43 rue Claude Caron 35959 Rousset-sur-Mer','Armées');
INSERT INTO Institution(nom,sigle,adresse,type) VALUES('Ministere des Sports','MS','585 rue Ledoux 41863 Le Gallnec','Sport');
INSERT INTO Institution(nom,sigle,adresse,type) VALUES('Ministere de l"Education','ME',' 76 chemin Louis Bruneau 50124 Laine-sur-Renaud','Education');
INSERT INTO Institution(nom,sigle,adresse,type) VALUES('Ministere de l"Enseignement','MEN' ,'464 boulevard Lesage 38168 Torres','Enseignement');
INSERT INTO Institution(nom,sigle,adresse,type) VALUES('Ministere de l"Argiculture ','MAG','952 boulevard Gaillard 71190 Sainte Amélie','Agriculture');





INSERT INTO Subvention(montant, date, idEnt, idInst)VALUES (1000, '2021-12-27',2,2);
INSERT INTO Subvention(montant, date, idEnt)VALUES (1000, '2021-12-24', 1);
INSERT INTO Subvention(montant, date, idInst)VALUES (950, '2021-12-24', 1);
INSERT INTO Subvention(montant, date, idEnt)VALUES (1500, '2021-12-27', 4);
INSERT INTO Subvention(montant, date, idEnt)VALUES (700, '2021-12-27', 5);
INSERT INTO Subvention(montant, date, idEnt)VALUES (150, '2021-12-27', 6);
INSERT INTO Subvention(montant, date, idEnt)VALUES (100, '2021-12-27', 7);
INSERT INTO Subvention(montant, date, idEnt)VALUES (1500, '2021-12-27', 8);
INSERT INTO Subvention(montant, date, idEnt)VALUES (350, '2021-12-27', 9);
INSERT INTO Subvention(montant, date, idEnt)VALUES (860, '2021-12-27', 10);
--INSERT INTO Subvention(montant, date, idEnt)VALUES (1280, '2021-12-27',11;
INSERT INTO Subvention(montant, date, idEnt)VALUES (1570, '2021-12-27',12);
INSERT INTO Subvention(montant, date, idEnt)VALUES (5000, '2021-12-27', 13);
INSERT INTO Subvention(montant, date, idEnt)VALUES (2300, '2021-12-27', 14);
INSERT INTO Subvention(montant, date, idEnt)VALUES (50, '2021-12-27', 15);
INSERT INTO Subvention(montant, date, idEnt)VALUES (1600, '2021-12-27', 8);
INSERT INTO Subvention(montant, date, idEnt)VALUES (1400, '2021-12-27', 12);
INSERT INTO Subvention(montant, date, idEnt)VALUES (1100, '2021-12-27', 6);
INSERT INTO Subvention(montant, date, idinst)VALUES (1000, '2021-12-27', 4);
INSERT INTO Subvention(montant, date, idinst)VALUES (700, '2021-12-27', 5);
INSERT INTO Subvention(montant, date, idinst)VALUES (1800, '2021-12-27', 6);
INSERT INTO Subvention(montant, date, idinst)VALUES (2100, '2021-12-27', 7);
INSERT INTO Subvention(montant, date, idinst)VALUES (1450, '2021-12-27', 8);
INSERT INTO Subvention(montant, date, idinst)VALUES (380, '2021-12-27', 9);


INSERT INTO PersonneM(idcontact,ident)VALUES (1,1);
--INSERT INTO PersonneM(idcontact)VALUES (4); /* ne passe pas
INSERT INTO PersonneM(idcontact,ident, idAss)VALUES (2,1,2);
INSERT INTO PersonneM(idcontact, idAss)VALUES (2,1);
INSERT INTO PersonneM(idcontact,ident, idAss, idinst)VALUES (3,2,1,1);
INSERT INTO personneM(idcontact, ident, idass)VALUES(5, 4, 5);
INSERT INTO personneM(idcontact, ident, idass)VALUES(7, 6, 2);
INSERT INTO personneM(idcontact, ident, idass)VALUES(12, 10, 8);
INSERT INTO personneM(idcontact, idinst, idass)VALUES(15, 5, 3);
INSERT INTO personneM(idcontact, idinst, idass)VALUES(17, 8, 6);
INSERT INTO personneM(idcontact, ident)VALUES(8, 6);
INSERT INTO personneM(idcontact, ident)VALUES(9, 13);
INSERT INTO personneM(idcontact, idass)VALUES(18, 8);












CREATE VIEW Activite_lucratif AS
(
SELECT  categorie, count(idcontact)
FROM participation NATURAL JOIN activité
GROUP BY  categorie
ORDER BY count(idcontact) DESC

);




CREATE VIEW meilleur_payeur AS
(
SELECT nomcomplet, montanttotal

FROM (SELECT nom||' '||prenom as nomcomplet, sum(montant) as montanttotal FROM don NATURAL JOIN versement NATURAL JOIN contact

GROUP BY idcontact, nom,prenom
ORDER BY sum(montant) DESC
LIMIT 5)as don

UNION

(SELECT nom as nomcomplet, sum(montant) as montanttotal FROM cotisation NATURAL JOIN association

GROUP BY idass, nom
ORDER BY sum(montant) DESC
LIMIT 5) 

UNION

(SELECT nom as nomcomplet, sum(montant) as montanttotal
FROM subvention NATURAL JOIN entreprise

GROUP BY ident, nom
ORDER BY sum(montant) DESC
LIMIT 5)

UNION

(SELECT nom as nomcomplet, sum(montant) as montanttotal
FROM subvention NATURAL JOIN  institution

GROUP BY idinst, nom
ORDER BY sum(montant) DESC
LIMIT 5)

ORDER BY montanttotal DESC
LIMIT 5
);












