import psycopg2
import psycopg2.extras

def connect():
  conn = psycopg2.connect(
    dbname = 'rayan.oukaci_db',
    host = 'sqletud.u-pem.fr',
    password = 'milanJSK@180902',
    cursor_factory = psycopg2.extras.NamedTupleCursor
  )
  conn.autocommit = True
  return conn
